MiniCut – jednoduchý video editor pro Android (Kotlin, Jetpack Compose, Media3)
1) Rozbal ZIP, v Android Studiu: File > Open > složka MiniCut, počkej na Gradle sync.
2) Build > Build APK(s), nebo Run na telefonu (Android 10+).

APK bez Android Studia: nahraj obsah složky MiniCut do nového GitHub repozitáře.
Záložka Actions > Build APK > po dokončení stáhni artefakt MiniCut-debug-apk (app-debug.apk).
Na telefonu povol instalaci z neznámých zdrojů a APK otevři.
