package cz.editor

import android.content.ContentValues
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import android.os.Bundle
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Template(
    val name: String, val speed: Float, val filter: String,
    val brightness: Float, val text: String, val mute: Boolean
)

val TEMPLATES = listOf(
    Template("Vlog", 1f, "Žádný", 0.1f, "", false),
    Template("Slow motion", 0.5f, "Žádný", 0f, "SLOW MO", false),
    Template("Time-lapse", 3f, "Žádný", 0f, "", true),
    Template("Retro", 1f, "Černobílý", -0.1f, "Retro", false),
    Template("Negativ", 1f, "Negativ", 0f, "", false)
)

@UnstableApi
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Editor() } }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Editor() {
        var uri by remember { mutableStateOf<Uri?>(null) }
        var durationMs by remember { mutableStateOf(0L) }
        var range by remember { mutableStateOf(0f..1f) }
        var speed by remember { mutableStateOf(1f) }
        var mute by remember { mutableStateOf(false) }
        var filter by remember { mutableStateOf("Žádný") }
        var brightness by remember { mutableStateOf(0f) }
        var text by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("") }
        var apiKey by remember { mutableStateOf(prefs().getString("key", "") ?: "") }
        var aiPrompt by remember { mutableStateOf("") }
        var aiReply by remember { mutableStateOf("") }
        var aiBusy by remember { mutableStateOf(false) }

        val player = remember { ExoPlayer.Builder(this).build() }
        DisposableEffect(Unit) {
            val l = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY && durationMs == 0L) durationMs = player.duration
                }
            }
            player.addListener(l)
            onDispose { player.removeListener(l); player.release() }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
            if (u != null) {
                uri = u; durationMs = 0L; range = 0f..1f
                player.setMediaItem(MediaItem.fromUri(u)); player.prepare()
            }
        }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = {
                picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            }) { Text("Vybrat video") }

            OutlinedTextField(
                value = apiKey, onValueChange = { apiKey = it; prefs().edit().putString("key", it).apply() },
                label = { Text("OpenAI API klíč (uložen šifrovaně)") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (uri != null) {
                AndroidView(factory = { PlayerView(it).apply { this.player = player } },
                    modifier = Modifier.fillMaxWidth().height(240.dp))

                Text("Šablony")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TEMPLATES.forEach { t ->
                        AssistChip(onClick = {
                            speed = t.speed; filter = t.filter; brightness = t.brightness
                            text = t.text; mute = t.mute
                        }, label = { Text(t.name) })
                    }
                }

                Text("AI asistent (ChatGPT)")
                OutlinedTextField(value = aiPrompt, onValueChange = { aiPrompt = it },
                    label = { Text("Např. „zpomal a udělej retro look s nápisem Léto“") },
                    modifier = Modifier.fillMaxWidth())
                Button(enabled = !aiBusy && apiKey.isNotBlank() && aiPrompt.isNotBlank(), onClick = {
                    aiBusy = true; aiReply = "Přemýšlím…"
                    askAi(apiKey, aiPrompt, uri!!, durationMs) { o, err ->
                        aiBusy = false
                        if (o == null) { aiReply = "Chyba: $err"; return@askAi }
                        speed = o.optDouble("speed", speed.toDouble()).toFloat().coerceIn(0.25f, 4f)
                        brightness = o.optDouble("brightness", brightness.toDouble()).toFloat().coerceIn(-0.5f, 0.5f)
                        o.optString("filter").takeIf { it in listOf("Žádný", "Černobílý", "Negativ") }?.let { filter = it }
                        if (o.has("text")) text = o.optString("text")
                        mute = o.optBoolean("mute", mute)
                        val a = o.optDouble("trimStart", range.start.toDouble()).toFloat().coerceIn(0f, 0.95f)
                        val b = o.optDouble("trimEnd", range.endInclusive.toDouble()).toFloat().coerceIn(a + 0.05f, 1f)
                        range = a..b
                        aiReply = o.optString("reply", "Hotovo, nastavení upraveno.")
                    }
                }) { Text("Upravit pomocí AI") }
                if (aiReply.isNotEmpty()) Text(aiReply)

                Text("Ořez: ${(range.start * durationMs / 1000).toInt()} s – ${(range.endInclusive * durationMs / 1000).toInt()} s")
                RangeSlider(value = range, onValueChange = {
                    range = it
                    player.seekTo((it.start * durationMs).toLong())
                })

                Text("Rychlost: ${"%.1f".format(speed)}×")
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.25f..4f)

                Text("Jas: ${"%.2f".format(brightness)}")
                Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -0.5f..0.5f)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Žádný", "Černobílý", "Negativ").forEach {
                        FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) })
                    }
                }
                Row { Checkbox(checked = mute, onCheckedChange = { mute = it }); Text("Ztlumit zvuk", Modifier.padding(top = 12.dp)) }
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Text přes video") }, modifier = Modifier.fillMaxWidth())

                Button(onClick = {
                    player.pause()
                    status = "Exportuji…"
                    export(uri!!, (range.start * durationMs).toLong(), (range.endInclusive * durationMs).toLong(),
                        speed, mute, filter, brightness, text) { status = it }
                }, modifier = Modifier.fillMaxWidth()) { Text("Exportovat do galerie") }
                if (status.isNotEmpty()) Text(status)
            }
        }
    }

    private fun prefs() = EncryptedSharedPreferences.create(
        this, "secure",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val SYSTEM = "Jsi asistent video editoru. Uživatel popíše úpravu videa česky. " +
        "Odpověz POUZE JSON objektem s klíči: speed (0.25-4), filter (\"Žádný\"|\"Černobílý\"|\"Negativ\"), " +
        "brightness (-0.5 až 0.5), text (nápis přes video, může být prázdný), mute (boolean), " +
        "trimStart a trimEnd (0-1, podíl délky videa), reply (krátké vysvětlení česky). " +
        "Dostaneš několik snímků z videa v rovnoměrných časech; vycházej z nich i z popisu (např. ořez podle obsahu); neuvedené hodnoty nech neutrální (speed 1, brightness 0, filter Žádný, trimStart 0, trimEnd 1)."

    private fun askAi(key: String, prompt: String, uri: Uri, durMs: Long, cb: (JSONObject?, String?) -> Unit) {
        Thread {
            try {
                val n = 4
                val shots = frames(uri, durMs, n)
                val pct = (0 until n).joinToString(", ") { "${(100 * (2 * it + 1)) / (2 * n)} %" }
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text",
                    "Délka videa: ${durMs / 1000} s. Snímky jsou z časů (podíl délky): $pct. Požadavek: $prompt"))
                shots.forEach {
                    parts.put(JSONObject().put("type", "image_url").put("image_url",
                        JSONObject().put("url", "data:image/jpeg;base64,$it").put("detail", "low")))
                }
                val body = JSONObject().put("model", "gpt-4o-mini")
                    .put("response_format", JSONObject().put("type", "json_object"))
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", SYSTEM))
                        .put(JSONObject().put("role", "user").put("content", parts)))
                val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("Authorization", "Bearer $key")
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                if (code !in 200..299) { runOnUiThread { cb(null, "HTTP $code (zkontroluj klíč a kredit)") }; return@Thread }
                val content = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                val result = JSONObject(content)
                runOnUiThread { cb(result, null) }
            } catch (e: Exception) { runOnUiThread { cb(null, e.message) } }
        }.start()
    }

    private fun frames(uri: Uri, durMs: Long, n: Int): List<String> {
        val r = MediaMetadataRetriever()
        val out = mutableListOf<String>()
        try {
            r.setDataSource(this, uri)
            for (i in 0 until n) {
                val tUs = durMs * (2 * i + 1) / (2 * n) * 1000
                val bmp = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val k = 512f / maxOf(bmp.width, bmp.height)
                val sm = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
                val bos = ByteArrayOutputStream()
                sm.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                out += Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            }
        } finally { r.release() }
        return out
    }

    private fun export(
        uri: Uri, startMs: Long, endMs: Long, speed: Float, mute: Boolean,
        filter: String, brightness: Float, text: String, onStatus: (String) -> Unit
    ) {
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs).setEndPositionMs(endMs).build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()

        val video = mutableListOf<Effect>()
        if (speed != 1f) video += SpeedChangeEffect(speed)
        when (filter) {
            "Černobílý" -> video += RgbFilter.createGrayscaleFilter()
            "Negativ" -> video += RgbFilter.createInvertedFilter()
        }
        if (brightness != 0f) video += Brightness(brightness)
        if (text.isNotBlank()) {
            val s = SpannableString(text).apply {
                setSpan(ForegroundColorSpan(android.graphics.Color.WHITE), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(AbsoluteSizeSpan(64), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            video += OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(s)))
        }
        val audio = mutableListOf<AudioProcessor>()
        if (speed != 1f) audio += SonicAudioProcessor().apply { setSpeed(speed); setPitch(speed) }

        val edited = EditedMediaItem.Builder(item)
            .setRemoveAudio(mute)
            .setEffects(Effects(audio, video))
            .build()

        val out = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")
        Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    saveToGallery(out); onStatus("Hotovo – uloženo v Movies/MiniCut")
                }
                override fun onError(composition: Composition, result: ExportResult, e: ExportException) {
                    onStatus("Chyba exportu: ${e.message}")
                }
            }).build().start(edited, out.absolutePath)
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MiniCut")
        }
        val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(dest)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
    }
}
